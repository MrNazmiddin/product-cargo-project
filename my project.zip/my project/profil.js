const imgInput = document.querySelector('#img-input')
const imgBox = document.querySelector('.image-upload-img-box')
const navSectionBtn = document.querySelector('.btn-nav-section')
const navSection = document.querySelector('.nav-section')
const mainSection = document.querySelector('.main-section')

let images = []

function createImgItem(){
    let imgItem = document.createElement('span')
    imgItem.className = 'img-box'
    return imgItem
}
function createImgFile(file){
    
}
imgInput.onchange = ()=>{
    let reader = new FileReader()
    let newItem = createImgItem()
    reader.readAsDataURL(imgInput.files[0])

    if(imgInput.files[0].type.split('/')[0] == 'image'){
        reader.onload = () => {
            newItem.style.backgroundImage = `url(${reader.result})`
        } 
        images.push(imgInput.files[0]);
        imgBox.append(newItem)
    }else{
        alert('rasm joylang !')
    }
}

function openNavSection(){}

navSectionBtn.addEventListener('click', (e)=>{
    console.log(e.target.classList[e.target.classList.length - 1]);
    navSection.style.left = '0rem'
    mainSection.addEventListener('click',(e)=>{
        if(e.target.className !== 'nav-section' && e.target.classList[e.target.classList.length - 1] !== 'btn-nav-section'){
            navSection.style.left = '-30rem'
        }
    })
})

navSection.addEventListener('click',(e)=>{
    let parentNode;
    if(e.target.className == 'nav-section-item-icon-box'){
        parentNode =  e.target.parentNode
    }else if(e.target.className == 'nav-section-item-title' || e.target.className == 'nav-section-item-number'){
        parentNode =  e.target.parentNode.parentNode
    }else if(e.target.className == 'nav-section-item-title-box'){
        parentNode =  e.target.parentNode
    }

    for (const i of parentNode.parentNode.children) {
        if(i == parentNode) i.classList.add('nav-section-item-active')
        else i.classList.remove('nav-section-item-active')
    }
})