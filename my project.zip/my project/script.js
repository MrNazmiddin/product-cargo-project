const shtora = document.querySelector('.shtora')
const shtoraBtn = document.querySelector('.btn-shtora')
const adNavsBtn = document.querySelector('.ad-navs-btn')
const adSection = document.querySelector('.ad-section')
const adsBox = document.querySelector('.ads-box')

let x = 0
shtoraBtn.addEventListener('click', ()=>{
    if(x == 0){
        shtora.style.transform = 'translateY(-0%)'
        x = 1
    }else if(x == 1){
        shtora.style.transform = 'translateY(-120%)'
        x = 0
    }
})
// function openAdNavs(){}

adNavsBtn.addEventListener('click', (e)=>{
    adSection.style.left = '3%'
    adsBox.addEventListener('click',(e)=>{
        if(e.target.className !== 'ad-section' && e.target.classList[e.target.classList.length - 1] !== 'ad-navs-btn'){
            adSection.style.left = '-45%'
        }
    })
    console.log('fdsdfsfsd');
})

/* ------------- */ 



/* ------------- */ 

