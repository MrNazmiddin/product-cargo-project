"use strict"
const carousel = document.querySelector('.new-cargo-box-items')
const carousel1 = document.querySelector('.new-cargo-carousel-box-items')
let event;
carousel.addEventListener('mousedown', ()=>{
    event = null
})
carousel.addEventListener('mouseup', ()=>{
    event = undefined
})
let dragging = (e)=>{
    if (event !== undefined) {
        event = e.movementX
        carousel.scrollLeft -= event
    }else{
        event = undefined
    }
}
carousel.addEventListener('mousemove',dragging)



for(let i = 0; i<=10; i++){
    let newCargoBoxItem = document.createElement('div')
    newCargoBoxItem.classList.add('new-cargo-box-item')
    newCargoBoxItem.innerHTML = `
        <span class="ellipse-7"></span>
        <span class="ellipse-8"></span>
        <div class="image-3"></div>
        <span class="location-logo"></span>
        <span class="new-cargo-title"><p>Помидор</p></span>
        <span class="new-txt"><p>новый</p></span>
        <span class="location-name"><p>Хорезм  -> Ташкент</p></span>
        <span class="time"><p>10.08.2023 | 18:00</p></span>
        <span class="price"><p>250$</p></span>
`
    carousel1.appendChild(newCargoBoxItem)
}

